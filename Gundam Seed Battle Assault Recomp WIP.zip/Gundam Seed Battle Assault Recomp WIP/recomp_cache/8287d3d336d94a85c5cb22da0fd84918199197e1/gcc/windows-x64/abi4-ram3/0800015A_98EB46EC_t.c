// AUTO-GENERATED Stage-2 self-heal overlay. Do not edit.
// function 0x0800015A mode=thumb end=0x0800015C
#include "overlay_runtime_arm.h"

#ifdef _WIN32
#define OVL_DLLEXPORT __declspec(dllexport)
#else
#define OVL_DLLEXPORT __attribute__((visibility("default")))
#endif
#ifdef __cplusplus
#define OVL_EXPORT extern "C" OVL_DLLEXPORT
#else
#define OVL_EXPORT OVL_DLLEXPORT
#endif

const GbaOverlayCallbacks* g_ovl = 0;
OVL_EXPORT uint32_t overlay_abi(void) { return 4u; }
OVL_EXPORT void overlay_init(const GbaOverlayCallbacks* cb) { g_ovl = cb; }

OVL_EXPORT void func_0800015A(void) {
    if (gba_mod_function_entry(0x0800015Au, 1u, &g_cpu)) return;
    if (g_runtime_fn_entry_hook) g_runtime_fn_entry_hook(0x0800015Au);
    /* 0800015A  0800015a T b 0x08000676 */
    g_cpu.R[15] = 0x0800015Au;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_0800015A = 1u;
    _cyc_0800015A = 3u;
    g_cpu.R[15] = 0x08000676u;
    runtime_tick(_cyc_0800015A);
    runtime_dispatch(0x08000676u);
    return;
    g_cpu.R[15] = 0x0800015Cu;
    runtime_tick(_cyc_0800015A);
    /* fall-through to 0x0800015C */
    g_cpu.R[15] = 0x0800015Cu;
    runtime_dispatch(0x0800015Cu);
    return;
}
