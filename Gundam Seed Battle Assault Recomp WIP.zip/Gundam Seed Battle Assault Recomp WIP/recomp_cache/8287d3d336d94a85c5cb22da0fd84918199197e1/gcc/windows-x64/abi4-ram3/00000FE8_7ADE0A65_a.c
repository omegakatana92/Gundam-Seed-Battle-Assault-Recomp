// AUTO-GENERATED Stage-2 self-heal overlay. Do not edit.
// function 0x00000FE8 mode=arm end=0x00000FF8
#include "overlay_runtime_arm.h"

#ifdef _WIN32
#define OVL_DLLEXPORT __declspec(dllexport)
#else
#define OVL_DLLEXPORT __attribute__((visibility("default")))
#endif
#ifdef __cplusplus
#define OVL_EXPORT extern "C" OVL_DLLEXPORT
#else
#define OVL_EXPORT OVL_DLLEXPORT
#endif

const GbaOverlayCallbacks* g_ovl = 0;
OVL_EXPORT uint32_t overlay_abi(void) { return 4u; }
OVL_EXPORT void overlay_init(const GbaOverlayCallbacks* cb) { g_ovl = cb; }

OVL_EXPORT void func_00000FE8(void) {
    if (gba_mod_function_entry(0x00000FE8u, 0u, &g_cpu)) return;
    if (g_runtime_fn_entry_hook) g_runtime_fn_entry_hook(0x00000FE8u);
    /* 00000FE8  00000fe8 A blt 0x00000ff8 */
    g_cpu.R[15] = 0x00000FE8u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_00000FE8 = 1u;
    if (arm_cond_passes(0xbu)) {
        _cyc_00000FE8 = 3u;
        g_cpu.R[15] = 0x00000FF8u;
        runtime_tick(_cyc_00000FE8);
        runtime_dispatch(0x00000FF8u);
        return;
    }
    g_cpu.R[15] = 0x00000FECu;
    runtime_tick(_cyc_00000FE8);
    /* 00000FEC  00000fec A str r14,[r1],#0x4 */
    g_cpu.R[15] = 0x00000FECu;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_00000FEC = 1u;
    _cyc_00000FEC = 1u;
    uint32_t _base_00000FEC = g_cpu.R[1];
    uint32_t _off_00000FEC;
    _off_00000FEC = 0x00000004u;
    uint32_t _ea_00000FEC = _base_00000FEC;
    uint32_t _post_00000FEC = _base_00000FEC + _off_00000FEC;
    _cyc_00000FEC += runtime_mem_cycles(_ea_00000FEC, 4u, 0u);
    runtime_trace_event(RUNTIME_TRACE_MEM_WRITE, 0x00000FECu, _ea_00000FEC & ~3u, g_cpu.R[14], 4u);
    bus_write_u32(_ea_00000FEC & ~3u, g_cpu.R[14]);
    g_cpu.R[1] = _post_00000FEC;
    g_cpu.R[15] = 0x00000FF0u;
    runtime_tick(_cyc_00000FEC);
    /* 00000FF0  00000ff0 A mov r14,#0x0 */
    g_cpu.R[15] = 0x00000FF0u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_00000FF0 = 1u;
    _cyc_00000FF0 = 1u;
    uint32_t _r_00000FF0;
    _r_00000FF0 = 0x00000000u;
    g_cpu.R[14] = _r_00000FF0;
    g_cpu.R[15] = 0x00000FF4u;
    runtime_tick(_cyc_00000FF0);
    /* 00000FF4  00000ff4 A mov r3,#0x0 */
    g_cpu.R[15] = 0x00000FF4u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_00000FF4 = 1u;
    _cyc_00000FF4 = 1u;
    uint32_t _r_00000FF4;
    _r_00000FF4 = 0x00000000u;
    g_cpu.R[3] = _r_00000FF4;
    g_cpu.R[15] = 0x00000FF8u;
    runtime_tick(_cyc_00000FF4);
    /* fall-through to 0x00000FF8 */
    g_cpu.R[15] = 0x00000FF8u;
    runtime_dispatch(0x00000FF8u);
    return;
}
