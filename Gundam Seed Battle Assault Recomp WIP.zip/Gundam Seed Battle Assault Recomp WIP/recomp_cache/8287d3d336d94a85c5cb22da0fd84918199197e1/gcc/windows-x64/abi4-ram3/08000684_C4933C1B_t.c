// AUTO-GENERATED Stage-2 self-heal overlay. Do not edit.
// function 0x08000684 mode=thumb end=0x0800069E
#include "overlay_runtime_arm.h"

#ifdef _WIN32
#define OVL_DLLEXPORT __declspec(dllexport)
#else
#define OVL_DLLEXPORT __attribute__((visibility("default")))
#endif
#ifdef __cplusplus
#define OVL_EXPORT extern "C" OVL_DLLEXPORT
#else
#define OVL_EXPORT OVL_DLLEXPORT
#endif

const GbaOverlayCallbacks* g_ovl = 0;
OVL_EXPORT uint32_t overlay_abi(void) { return 4u; }
OVL_EXPORT void overlay_init(const GbaOverlayCallbacks* cb) { g_ovl = cb; }

OVL_EXPORT void func_08000684(void) {
    if (gba_mod_function_entry(0x08000684u, 1u, &g_cpu)) return;
    if (g_runtime_fn_entry_hook) g_runtime_fn_entry_hook(0x08000684u);
    /* 08000684  08000684 T strh r4,[r5] */
    g_cpu.R[15] = 0x08000684u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000684 = 1u;
    _cyc_08000684 = 1u;
    uint32_t _base_08000684 = g_cpu.R[5];
    uint32_t _off_08000684;
    _off_08000684 = 0x00000000u;
    uint32_t _ea_08000684 = _base_08000684 + _off_08000684;
    uint32_t _post_08000684 = _base_08000684 + _off_08000684;
    _cyc_08000684 += runtime_mem_cycles(_ea_08000684, 2u, 0u);
    runtime_trace_event(RUNTIME_TRACE_MEM_WRITE, 0x08000684u, _ea_08000684 & ~1u, (uint32_t)(g_cpu.R[4] & 0xFFFFu), 2u);
    bus_write_u16(_ea_08000684 & ~1u, (uint16_t)(g_cpu.R[4] & 0xFFFFu));
    g_cpu.R[15] = 0x08000686u;
    runtime_tick(_cyc_08000684);
    /* 08000686  08000686 T ldr r1,[r15,#0x24] */
    g_cpu.R[15] = 0x08000686u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000686 = 1u;
    _cyc_08000686 = 2u;
    uint32_t _base_08000686 = 0x0800068Au & ~3u;
    uint32_t _off_08000686;
    _off_08000686 = 0x00000024u;
    uint32_t _ea_08000686 = _base_08000686 + _off_08000686;
    uint32_t _post_08000686 = _base_08000686 + _off_08000686;
    _cyc_08000686 += runtime_mem_cycles(_ea_08000686, 4u, 0u);
    uint32_t _v_08000686;
    { uint32_t _w = bus_read_u32(_ea_08000686 & ~3u); uint32_t _rot = (_ea_08000686 & 3u) * 8u; _v_08000686 = (_rot == 0u) ? _w : ((_w >> _rot) | (_w << (32u - _rot))); }
    g_cpu.R[1] = _v_08000686;
    g_cpu.R[15] = 0x08000688u;
    runtime_tick(_cyc_08000686);
    /* 08000688  08000688 T str r5,[r1] */
    g_cpu.R[15] = 0x08000688u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000688 = 1u;
    _cyc_08000688 = 1u;
    uint32_t _base_08000688 = g_cpu.R[1];
    uint32_t _off_08000688;
    _off_08000688 = 0x00000000u;
    uint32_t _ea_08000688 = _base_08000688 + _off_08000688;
    uint32_t _post_08000688 = _base_08000688 + _off_08000688;
    _cyc_08000688 += runtime_mem_cycles(_ea_08000688, 4u, 0u);
    runtime_trace_event(RUNTIME_TRACE_MEM_WRITE, 0x08000688u, _ea_08000688 & ~3u, g_cpu.R[5], 4u);
    bus_write_u32(_ea_08000688 & ~3u, g_cpu.R[5]);
    g_cpu.R[15] = 0x0800068Au;
    runtime_tick(_cyc_08000688);
    /* 0800068A  0800068a T movs r0,#0xa0 */
    g_cpu.R[15] = 0x0800068Au;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_0800068A = 1u;
    _cyc_0800068A = 1u;
    uint32_t _r_0800068A;
    _r_0800068A = 0x000000A0u;
    arm_set_nzc_logic(_r_0800068A, cpsr_c());
    g_cpu.R[0] = _r_0800068A;
    g_cpu.R[15] = 0x0800068Cu;
    runtime_tick(_cyc_0800068A);
    /* 0800068C  0800068c T movs r0,r0,lsl #19 */
    g_cpu.R[15] = 0x0800068Cu;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_0800068C = 1u;
    _cyc_0800068C = 1u;
    uint32_t _rm_0800068C = g_cpu.R[0];
    uint32_t _op2_0800068C;
    uint32_t _co_0800068C;
    _op2_0800068C = _rm_0800068C << 19;
    _co_0800068C = (_rm_0800068C >> 13) & 1u;
    uint32_t _r_0800068C;
    _r_0800068C = _op2_0800068C;
    arm_set_nzc_logic(_r_0800068C, _co_0800068C);
    g_cpu.R[0] = _r_0800068C;
    g_cpu.R[15] = 0x0800068Eu;
    runtime_tick(_cyc_0800068C);
    /* 0800068E  0800068e T str r0,[r1,#0x4] */
    g_cpu.R[15] = 0x0800068Eu;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_0800068E = 1u;
    _cyc_0800068E = 1u;
    uint32_t _base_0800068E = g_cpu.R[1];
    uint32_t _off_0800068E;
    _off_0800068E = 0x00000004u;
    uint32_t _ea_0800068E = _base_0800068E + _off_0800068E;
    uint32_t _post_0800068E = _base_0800068E + _off_0800068E;
    _cyc_0800068E += runtime_mem_cycles(_ea_0800068E, 4u, 0u);
    runtime_trace_event(RUNTIME_TRACE_MEM_WRITE, 0x0800068Eu, _ea_0800068E & ~3u, g_cpu.R[0], 4u);
    bus_write_u32(_ea_0800068E & ~3u, g_cpu.R[0]);
    g_cpu.R[15] = 0x08000690u;
    runtime_tick(_cyc_0800068E);
    /* 08000690  08000690 T ldr r0,[r15,#0x1c] */
    g_cpu.R[15] = 0x08000690u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000690 = 1u;
    _cyc_08000690 = 2u;
    uint32_t _base_08000690 = 0x08000694u & ~3u;
    uint32_t _off_08000690;
    _off_08000690 = 0x0000001Cu;
    uint32_t _ea_08000690 = _base_08000690 + _off_08000690;
    uint32_t _post_08000690 = _base_08000690 + _off_08000690;
    _cyc_08000690 += runtime_mem_cycles(_ea_08000690, 4u, 0u);
    uint32_t _v_08000690;
    { uint32_t _w = bus_read_u32(_ea_08000690 & ~3u); uint32_t _rot = (_ea_08000690 & 3u) * 8u; _v_08000690 = (_rot == 0u) ? _w : ((_w >> _rot) | (_w << (32u - _rot))); }
    g_cpu.R[0] = _v_08000690;
    g_cpu.R[15] = 0x08000692u;
    runtime_tick(_cyc_08000690);
    /* 08000692  08000692 T str r0,[r1,#0x8] */
    g_cpu.R[15] = 0x08000692u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000692 = 1u;
    _cyc_08000692 = 1u;
    uint32_t _base_08000692 = g_cpu.R[1];
    uint32_t _off_08000692;
    _off_08000692 = 0x00000008u;
    uint32_t _ea_08000692 = _base_08000692 + _off_08000692;
    uint32_t _post_08000692 = _base_08000692 + _off_08000692;
    _cyc_08000692 += runtime_mem_cycles(_ea_08000692, 4u, 0u);
    runtime_trace_event(RUNTIME_TRACE_MEM_WRITE, 0x08000692u, _ea_08000692 & ~3u, g_cpu.R[0], 4u);
    bus_write_u32(_ea_08000692 & ~3u, g_cpu.R[0]);
    g_cpu.R[15] = 0x08000694u;
    runtime_tick(_cyc_08000692);
    /* 08000694  08000694 T ldr r0,[r1,#0x8] */
    g_cpu.R[15] = 0x08000694u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000694 = 1u;
    _cyc_08000694 = 2u;
    uint32_t _base_08000694 = g_cpu.R[1];
    uint32_t _off_08000694;
    _off_08000694 = 0x00000008u;
    uint32_t _ea_08000694 = _base_08000694 + _off_08000694;
    uint32_t _post_08000694 = _base_08000694 + _off_08000694;
    _cyc_08000694 += runtime_mem_cycles(_ea_08000694, 4u, 0u);
    uint32_t _v_08000694;
    { uint32_t _w = bus_read_u32(_ea_08000694 & ~3u); uint32_t _rot = (_ea_08000694 & 3u) * 8u; _v_08000694 = (_rot == 0u) ? _w : ((_w >> _rot) | (_w << (32u - _rot))); }
    g_cpu.R[0] = _v_08000694;
    g_cpu.R[15] = 0x08000696u;
    runtime_tick(_cyc_08000694);
    /* 08000696  08000696 T add r13,r13,#0xc */
    g_cpu.R[15] = 0x08000696u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000696 = 1u;
    _cyc_08000696 = 1u;
    uint32_t _rn_08000696 = g_cpu.R[13];
    uint32_t _r_08000696;
    _r_08000696 = _rn_08000696 + 0x0000000Cu;
    g_cpu.R[13] = _r_08000696;
    g_cpu.R[15] = 0x08000698u;
    runtime_tick(_cyc_08000696);
    /* 08000698  08000698 T ldm r13!,{r4,r5} */
    g_cpu.R[15] = 0x08000698u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000698 = 1u;
    _cyc_08000698 = 2u;
    uint32_t _b_08000698 = g_cpu.R[13];
    uint32_t _a_08000698 = _b_08000698;
    uint32_t _fb_08000698 = _b_08000698 + 8u;
    _cyc_08000698 += runtime_mem_cycles(_a_08000698 & ~3u, 4u, 0u);
    g_cpu.R[4] = bus_read_u32(_a_08000698 & ~3u);
    _a_08000698 += 4u;
    _cyc_08000698 += runtime_mem_cycles(_a_08000698 & ~3u, 4u, 1u);
    g_cpu.R[5] = bus_read_u32(_a_08000698 & ~3u);
    _a_08000698 += 4u;
    g_cpu.R[13] = _fb_08000698;
    g_cpu.R[15] = 0x0800069Au;
    runtime_tick(_cyc_08000698);
    /* 0800069A  0800069a T ldm r13!,{r0} */
    g_cpu.R[15] = 0x0800069Au;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_0800069A = 1u;
    _cyc_0800069A = 2u;
    uint32_t _b_0800069A = g_cpu.R[13];
    uint32_t _a_0800069A = _b_0800069A;
    uint32_t _fb_0800069A = _b_0800069A + 4u;
    _cyc_0800069A += runtime_mem_cycles(_a_0800069A & ~3u, 4u, 0u);
    g_cpu.R[0] = bus_read_u32(_a_0800069A & ~3u);
    _a_0800069A += 4u;
    g_cpu.R[13] = _fb_0800069A;
    g_cpu.R[15] = 0x0800069Cu;
    runtime_tick(_cyc_0800069A);
    /* 0800069C  0800069c T bx r0 */
    g_cpu.R[15] = 0x0800069Cu;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_0800069C = 1u;
    _cyc_0800069C = 3u;
    uint32_t _bxt_0800069C = g_cpu.R[0];
    g_cpu.R[15] = _bxt_0800069C & ~1u;
    if (_bxt_0800069C & 1u) g_cpu.cpsr |= CPSR_T_BIT; else g_cpu.cpsr &= ~CPSR_T_BIT;
    runtime_tick(_cyc_0800069C);
    if (runtime_call_should_return(g_cpu.R[15])) return;
    runtime_dispatch_with_exchange(_bxt_0800069C);
    return;
    g_cpu.R[15] = 0x0800069Eu;
    runtime_tick(_cyc_0800069C);
    /* fall-through to 0x0800069E */
    g_cpu.R[15] = 0x0800069Eu;
    runtime_dispatch(0x0800069Eu);
    return;
}
