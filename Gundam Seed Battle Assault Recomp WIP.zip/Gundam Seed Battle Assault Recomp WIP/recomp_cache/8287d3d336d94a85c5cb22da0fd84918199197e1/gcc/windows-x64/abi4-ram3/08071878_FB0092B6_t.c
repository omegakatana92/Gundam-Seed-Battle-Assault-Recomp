// AUTO-GENERATED Stage-2 self-heal overlay. Do not edit.
// function 0x08071878 mode=thumb end=0x0807187A
#include "overlay_runtime_arm.h"

#ifdef _WIN32
#define OVL_DLLEXPORT __declspec(dllexport)
#else
#define OVL_DLLEXPORT __attribute__((visibility("default")))
#endif
#ifdef __cplusplus
#define OVL_EXPORT extern "C" OVL_DLLEXPORT
#else
#define OVL_EXPORT OVL_DLLEXPORT
#endif

const GbaOverlayCallbacks* g_ovl = 0;
OVL_EXPORT uint32_t overlay_abi(void) { return 4u; }
OVL_EXPORT void overlay_init(const GbaOverlayCallbacks* cb) { g_ovl = cb; }

OVL_EXPORT void func_08071878(void) {
    if (gba_mod_function_entry(0x08071878u, 1u, &g_cpu)) return;
    if (g_runtime_fn_entry_hook) g_runtime_fn_entry_hook(0x08071878u);
    /* 08071878  08071878 T swi #0xc */
    g_cpu.R[15] = 0x08071878u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08071878 = 1u;
    g_cpu.R[15] = 0x0807187Au;
    runtime_swi(0x0000000Cu);
    return;
    g_cpu.R[15] = 0x0807187Au;
    runtime_tick(_cyc_08071878);
    /* fall-through to 0x0807187A */
    g_cpu.R[15] = 0x0807187Au;
    runtime_dispatch(0x0807187Au);
    return;
}
