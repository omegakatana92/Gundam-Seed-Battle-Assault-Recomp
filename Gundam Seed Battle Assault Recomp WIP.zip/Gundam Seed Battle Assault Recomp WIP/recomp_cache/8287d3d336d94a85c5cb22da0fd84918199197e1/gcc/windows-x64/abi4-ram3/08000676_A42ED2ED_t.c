// AUTO-GENERATED Stage-2 self-heal overlay. Do not edit.
// function 0x08000676 mode=thumb end=0x08000684
#include "overlay_runtime_arm.h"

#ifdef _WIN32
#define OVL_DLLEXPORT __declspec(dllexport)
#else
#define OVL_DLLEXPORT __attribute__((visibility("default")))
#endif
#ifdef __cplusplus
#define OVL_EXPORT extern "C" OVL_DLLEXPORT
#else
#define OVL_EXPORT OVL_DLLEXPORT
#endif

const GbaOverlayCallbacks* g_ovl = 0;
OVL_EXPORT uint32_t overlay_abi(void) { return 4u; }
OVL_EXPORT void overlay_init(const GbaOverlayCallbacks* cb) { g_ovl = cb; }

OVL_EXPORT void func_08000676(void) {
    if (gba_mod_function_entry(0x08000676u, 1u, &g_cpu)) return;
    if (g_runtime_fn_entry_hook) g_runtime_fn_entry_hook(0x08000676u);
    /* 08000676  08000676 T movs r4,#0x0 */
    g_cpu.R[15] = 0x08000676u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000676 = 1u;
    _cyc_08000676 = 1u;
    uint32_t _r_08000676;
    _r_08000676 = 0x00000000u;
    arm_set_nzc_logic(_r_08000676, cpsr_c());
    g_cpu.R[4] = _r_08000676;
    g_cpu.R[15] = 0x08000678u;
    runtime_tick(_cyc_08000676);
    /* 08000678  08000678 T str r4,[r13,#0x4] */
    g_cpu.R[15] = 0x08000678u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000678 = 1u;
    _cyc_08000678 = 1u;
    uint32_t _base_08000678 = g_cpu.R[13];
    uint32_t _off_08000678;
    _off_08000678 = 0x00000004u;
    uint32_t _ea_08000678 = _base_08000678 + _off_08000678;
    uint32_t _post_08000678 = _base_08000678 + _off_08000678;
    _cyc_08000678 += runtime_mem_cycles(_ea_08000678, 4u, 0u);
    runtime_trace_event(RUNTIME_TRACE_MEM_WRITE, 0x08000678u, _ea_08000678 & ~3u, g_cpu.R[4], 4u);
    bus_write_u32(_ea_08000678 & ~3u, g_cpu.R[4]);
    g_cpu.R[15] = 0x0800067Au;
    runtime_tick(_cyc_08000678);
    /* 0800067A  0800067a T movs r1,#0xc0 */
    g_cpu.R[15] = 0x0800067Au;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_0800067A = 1u;
    _cyc_0800067A = 1u;
    uint32_t _r_0800067A;
    _r_0800067A = 0x000000C0u;
    arm_set_nzc_logic(_r_0800067A, cpsr_c());
    g_cpu.R[1] = _r_0800067A;
    g_cpu.R[15] = 0x0800067Cu;
    runtime_tick(_cyc_0800067A);
    /* 0800067C  0800067c T movs r1,r1,lsl #19 */
    g_cpu.R[15] = 0x0800067Cu;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_0800067C = 1u;
    _cyc_0800067C = 1u;
    uint32_t _rm_0800067C = g_cpu.R[1];
    uint32_t _op2_0800067C;
    uint32_t _co_0800067C;
    _op2_0800067C = _rm_0800067C << 19;
    _co_0800067C = (_rm_0800067C >> 13) & 1u;
    uint32_t _r_0800067C;
    _r_0800067C = _op2_0800067C;
    arm_set_nzc_logic(_r_0800067C, _co_0800067C);
    g_cpu.R[1] = _r_0800067C;
    g_cpu.R[15] = 0x0800067Eu;
    runtime_tick(_cyc_0800067C);
    /* 0800067E  0800067e T ldr r2,[r15,#0x28] */
    g_cpu.R[15] = 0x0800067Eu;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_0800067E = 1u;
    _cyc_0800067E = 2u;
    uint32_t _base_0800067E = 0x08000682u & ~3u;
    uint32_t _off_0800067E;
    _off_0800067E = 0x00000028u;
    uint32_t _ea_0800067E = _base_0800067E + _off_0800067E;
    uint32_t _post_0800067E = _base_0800067E + _off_0800067E;
    _cyc_0800067E += runtime_mem_cycles(_ea_0800067E, 4u, 0u);
    uint32_t _v_0800067E;
    { uint32_t _w = bus_read_u32(_ea_0800067E & ~3u); uint32_t _rot = (_ea_0800067E & 3u) * 8u; _v_0800067E = (_rot == 0u) ? _w : ((_w >> _rot) | (_w << (32u - _rot))); }
    g_cpu.R[2] = _v_0800067E;
    g_cpu.R[15] = 0x08000680u;
    runtime_tick(_cyc_0800067E);
    /* 08000680  08000680 T bl.hi 0x08071684 */
    g_cpu.R[15] = 0x08000680u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000680 = 1u;
    _cyc_08000680 = 1u;
    g_cpu.R[14] = 0x08071684u;
    g_cpu.R[15] = 0x08000682u;
    runtime_tick(_cyc_08000680);
    /* 08000682  08000682 T bl.lo 0x00000000 */
    g_cpu.R[15] = 0x08000682u;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_08000682 = 1u;
    _cyc_08000682 = 3u;
    uint32_t _blt_08000682 = (g_cpu.R[14] + 0x000001F4u) & ~1u;
    g_cpu.R[14] = 0x08000685u;
    g_cpu.R[15] = _blt_08000682;
    runtime_call_push_return(0x08000684u);
    runtime_tick(_cyc_08000682);
    _cyc_08000682 = 0u;
    runtime_dispatch(_blt_08000682);
    if (g_cpu.R[15] != 0x08000684u) { runtime_call_cancel_return(0x08000684u); return; }
    g_cpu.R[15] = 0x08000684u;
    runtime_tick(_cyc_08000682);
    /* fall-through to 0x08000684 */
    g_cpu.R[15] = 0x08000684u;
    runtime_dispatch(0x08000684u);
    return;
}
