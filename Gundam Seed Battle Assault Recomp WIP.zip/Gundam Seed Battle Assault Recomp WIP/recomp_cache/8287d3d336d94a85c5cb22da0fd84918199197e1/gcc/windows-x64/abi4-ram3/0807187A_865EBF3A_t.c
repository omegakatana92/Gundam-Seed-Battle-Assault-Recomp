// AUTO-GENERATED Stage-2 self-heal overlay. Do not edit.
// function 0x0807187A mode=thumb end=0x0807187C
#include "overlay_runtime_arm.h"

#ifdef _WIN32
#define OVL_DLLEXPORT __declspec(dllexport)
#else
#define OVL_DLLEXPORT __attribute__((visibility("default")))
#endif
#ifdef __cplusplus
#define OVL_EXPORT extern "C" OVL_DLLEXPORT
#else
#define OVL_EXPORT OVL_DLLEXPORT
#endif

const GbaOverlayCallbacks* g_ovl = 0;
OVL_EXPORT uint32_t overlay_abi(void) { return 4u; }
OVL_EXPORT void overlay_init(const GbaOverlayCallbacks* cb) { g_ovl = cb; }

OVL_EXPORT void func_0807187A(void) {
    if (gba_mod_function_entry(0x0807187Au, 1u, &g_cpu)) return;
    if (g_runtime_fn_entry_hook) g_runtime_fn_entry_hook(0x0807187Au);
    /* 0807187A  0807187a T bx r14 */
    g_cpu.R[15] = 0x0807187Au;
    if (runtime_should_yield()) return;
    if (g_runtime_insn_trace) runtime_insn_fp();
    uint32_t _cyc_0807187A = 1u;
    _cyc_0807187A = 3u;
    uint32_t _bxt_0807187A = g_cpu.R[14];
    g_cpu.R[15] = _bxt_0807187A & ~1u;
    if (_bxt_0807187A & 1u) g_cpu.cpsr |= CPSR_T_BIT; else g_cpu.cpsr &= ~CPSR_T_BIT;
    runtime_tick(_cyc_0807187A);
    if (runtime_call_should_return(g_cpu.R[15])) return;
    runtime_dispatch_with_exchange(_bxt_0807187A);
    return;
    g_cpu.R[15] = 0x0807187Cu;
    runtime_tick(_cyc_0807187A);
    /* fall-through to 0x0807187C */
    g_cpu.R[15] = 0x0807187Cu;
    runtime_dispatch(0x0807187Cu);
    return;
}
