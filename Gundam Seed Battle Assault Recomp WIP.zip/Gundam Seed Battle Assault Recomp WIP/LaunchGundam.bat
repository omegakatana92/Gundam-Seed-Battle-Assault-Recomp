@echo off
REM Gundam Seed - Battle Assault launcher with optimized audio and performance settings
REM Place this file in the same directory as GEMiniRecomp.exe

setlocal

REM === Performance Settings ===
REM Disable interpreter mode for better performance (uses recompiled code)
set GBARECOMP_FORCE_INTERP=0

REM Enable present-in-place for smoother frame presentation
set GBARECOMP_PRESENT_IN_PLACE=1

REM Disable vsync to avoid frame pacing issues (the FramePacer handles timing)
set GBARECOMP_NO_VSYNC=1

REM === Audio Settings ===
REM Use the RAB audio bridge (resampler) for smooth audio
set GBARECOMP_AUDIO_DIRECT=0

REM Audio buffer size in ms - higher values reduce crackling but increase latency
set GBARECOMP_AUDIO_BUFFER_MS=60

REM === Compatibility Settings ===
REM Use HLE BIOS for faster boot
set GBARECOMP_BIOS_HLE=1

REM Disable self-heal recompilation (can cause stutters)
set GBARECOMP_SELFHEAL_RECOMPILE=0

REM === Launch Game ===
start "" "%~dp0GEMiniRecomp.exe" %*
